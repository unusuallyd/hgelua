//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resources.rc
//
#define IDD_DIALOG1                     101
#define IDR_MAINMENU                    102
#define ID_CLOSE                        1000
#define ID_CLOSEMENU                    40001
#define ID_OPTIONS_SHOWTRAILS           40002
#define ID_OPTIONS_SHOWVECTORS          40003
#define ID_OPTIONS_BASICCHASE           40004
#define ID_OPTIONS_BASICEVADE           40005
#define ID_OPTIONS_INTERCEPT            40006
#define ID_OPTIONS_POTENTIALCHASE       40007
#define ID_OPTIONS_SQUAREPATROL         40009
#define ID_OPTIONS_ZIGZAG               40010
#define ID_OPTIONS_WIDEFIELDOFVIEW      40011
#define ID_OPTIONS_SWARM                40011
#define ID_OPTIONS_LIMITEDFIELDOFVIEW   40012
#define ID_OPTIONS_NARROWFIELDOFVIEW    40013
#define ID_OPTIONS_CHASEMOUSE           40014
#define ID_OPTIONS_AVOID                40015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40016
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
